#' @title A dataset containing the quantitative trait and the genotype of a SNP with no missing values for only pedigrees
#'
#' @description The dataset includes 30 pedigrees  with 260 individuals (130 females and 130 males).
#'
#' @docType data
#' @keywords datasets
#' @name pedigree_data_1
#' @usage pedigree_data_1
#' @format
#' \describe{
#' \item{famid}{Pedigree ID.}
#' \item{iid}{Individual ID.}
#' \item{fid}{Father ID.}
#' \item{mid}{Mother ID.}
#' \item{sex}{The genetic sex of the individual, coded as 1 for males and 2 for females, following the PLINK default coding.}
#' \item{trait}{A numeric variable of the quantitative trait.}
#' \item{genotype}{The genotype of the target SNP, coded as 0, 1 or 2, indicating the number of the minor alleles.}
#' }
NULL
