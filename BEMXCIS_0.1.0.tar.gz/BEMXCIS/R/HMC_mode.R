#' @title A function to obtain the mode of the samples
#'
#' @description A function to obtain the mode of the samples.
#' @usage HMC_mode(sam_chain)
#'
#' @param sam_chain A vector contains the samples.
#'
#' @return The HMC_mode() returns a value.
#' @export
#'
#' @author Yi-Fan Kong and Ji-Yuan Zhou
#' @keywords function
#' @examples HMC_mode(runif(100,5,50))
#'
HMC_mode <- function(sam_chain){
  dd <- density(sam_chain)
  dd$x[which.max(dd$y)]
}
