#' @title A dataset containing the covariates for qualitative traits based on mixed data
#'
#' @description The dataset contains two covariates for 30 pedigrees with 260 individuals (130 females and 130 males) and additional 130 unrelated females.
#'
#' @docType data
#' @keywords datasets
#' @name covariate_data_mixed_2
#' @usage covariate_data_mixed_2
#' @format
#' \describe{
#' \item{famid}{Pedigree ID.}
#' \item{iid}{Individual ID.}
#' \item{fid}{Father ID.}
#' \item{mid}{Mother ID.}
#' \item{sex}{The genetic sex of the individual, coded as 1 for males and 2 for females, following the PLINK default coding.}
#' \item{covariate1}{A quantitative covariate.}
#' \item{covariate2}{A qualitative covariate.}
#' }
NULL
