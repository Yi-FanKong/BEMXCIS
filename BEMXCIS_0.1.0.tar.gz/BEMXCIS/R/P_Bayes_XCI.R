#' @title The Bayesian method for estimating the degree of the skewness of X chromosome inactivation based on only pedigrees
#' @description This code contains the Bayesian method for estimating the degree of the skewness of X chromosome inactivation for either quantitative traits or qualitative traits, with or without covariates using only pedigrees
#' @usage P_Bayes_XCI(pedigree_data, covariate=NULL, trait_type, trait_missing=NA,
#'                   genotype_missing=NA, covariate_missing=NA, gamma_prior="normal",
#'                   prior_customize=NULL, chains_num=4, parallel_chains=4,
#'                   iter_num=2000, warmup_num=1000, acceptance_rate=0.9, decimal=4)
#'
#' @param pedigree_data A data frame containing the pedigree data. The first five columns of the data frame must include: famid (pedigree Id), iid (individual ID), fid (father ID), mid (mother ID) and sex. The numerical codes for sex are 0=unknown, 1=male, 2=female. The sixth column is the trait value. For qualitative traits, the numerical codes are 0=unaffected, 1=affected. The seventh column is the genotype of target SNP, which is coded as 0, 1 and 2, indicating the number of minor alleles. The details can be referred to example data "pedigree_data_1".
#' @param covariate A data frame containing covariates (optional). The first five columns should be consistent with that in the parameter "pedigree_data". The sixth to last columns are the covariates you want to add. The details can be referred to example data "covariate_data_pedigree_1".
#' @param trait_type A character string either being "quantitative" or "qualitative", indicating the type of the trait.
#' @param trait_missing The format of missing value for the trait in the parameter "pedigree_data" and "covariate" (optional), and the default value is NA. It may be 9 in some data files; or other numeric values.
#' @param genotype_missing The format of missing value for the genotype in the parameter "pedigree_data" and "covariate" (optional), and the default value is NA. It may be 9 in some data files; or other numeric values.
#' @param covariate_missing The format of missing value for the covariate in the parameter "covariate" (optional), and the default value is NA. It may be 9 in some data files; or other numeric values.
#' @param gamma_prior A character string either being "normal", "uniform" or "customize". The "normal" represents that the prior distribution of \eqn{\gamma} is a truncated normal distribution with both parameters being 1 and the values ranging from 0 to 2; The "uniform" represents that the prior distribution of \eqn{\gamma} is the uniform distribution \eqn{\gamma}~U(0, 2); The "customize" indicates that the users could specify the prior distributions of \eqn{\gamma} and other unknown parameters according to their own research background. When "normal" or "uniform", other unknown parameters of model are set to defaults, which are according to the first article in the references.
#' @param prior_customize A Stan model in Stan language, activated only when the parameter "gamma_prior" is set to "customize". You can customize the prior distributions of \eqn{\gamma} and other unknown parameters here. Please see the example 3 and example 4 for the details.
#' @param chains_num A positive integer specifying the number of Markov chains. The default is 4.
#' @param parallel_chains A positive integer specifying the maximum number of MCMC chains to run in parallel. The default is 4. You can set it to the maximum number of CPU cores of your computer.
#' @param iter_num A positive integer specifying the number of post-warmup iterations to run per chain. The default is 2000.
#' @param warmup_num A positive integer specifying the number of warmup iterations to run per chain. The default is 1000.
#' @param acceptance_rate A value between 0 and 1 that represents the target acceptance rate, the default is 0.9.
#' @param decimal A positive integer specifying the number of decimal digits remained in results
#'
#' @details Please install the "cmdstanr" package and make sure it can work before using the P_Bayes_XCI. The "cmdstanr" package cannot be installed by CRAN, and please refer to the tutorial https://mc-stan.org/cmdstanr/index.html to install. Note that we measure the degree of the skewness of X chromosome inactivation in the presence of association. So the trait and the target SNP you include in the parameter "pedigree_data" must be associated. The pedigree structure in the parameter "pedigree_data" should be complete, for example, even the fid and mid of a offspring are missing, the individuals corresponding them also should be included in the data as NA or other values. The results may be different for different runs, because of the sampling randomness of the HMC algorithm. If the fixed results are wanted, seed number should be set before running the function. Because cmdstanr runs HMC sampling in C language, the stan file in R language needs to be compiled into C language before each run, which may take some extra time.
#' @return
#' \item{Point_Estimate}{The point estimate of the degree of the skewness of X chromosome inactivation for the target SNP based on the pedigree data by Bayesian method.}
#' \item{HPDI_Lower}{The lower bound of the HPDI.}
#' \item{HPDI_Upper}{The upper bound of the HPDI.}
#' \item{Rhat}{A diagnostic factor assesses convergence of Markov chains. Rhat>1.05 indicates that the Markov chain does not converge, then you should increase "iter_num" and "acceptance_rate", or reconsider prior)}
#' @export
#' @references Yi-Fan Kong, Shi-Zhu Li, Kai-Wen Wang, Bin Zhu, Yu-Xin Yuan, Meng-Kai Li and Ji-Yuan Zhou. An Efficient Bayesian Method for Estimating the Degree of the Skewness of X Chromosome Inactivation Based on the Mixture of General Pedigrees and Unrelated Females. 2023
#' @references Annis J., Miller BJ. and Palmeri TJ. Bayesian inference with Stan: A tutorial on adding custom distributions. Behav. Res. Methods 2017, 49, 863-886.
#' @author Yi-Fan Kong, Shi-Zhu Li and Ji-Yuan Zhou
#'
#' @note The interval not containing 1 indicates the skewed X chromosome inactivation (XCI-S), otherwise it suggests the random X chromosome inactivation (XCI-R) or the escape from X chromosome inactivation (XCI-E).
#' @keywords function
#'
#' @examples
#'
#' library(cmdstanr)
#' library(kinship2)
#'
#' ##example 1:
#' ##pedigree data for quantitative trait with covariates.
#' ##the prior of gamma is set to truncated normal distribution and other parameters are set to defaults.
#' set.seed(123456)
#' P_Bayes_XCI(pedigree_data=pedigree_data_1,covariate=covariate_data_pedigree_1,trait_type="quantitative",
#'             gamma_prior="normal")
#' #results:
#' #SNP_Name Point_Estimate HPDI_Lower HPDI_Upper   Rhat
#' #rs123456         0.6351          0     1.4811 1.0004
#'
#' ##example 2:
#' ##pedigree data for quantitative trait with covariates.
#' ##the prior of gamma is set to uniform distribution and other parameters are set to defaults.
#' set.seed(123456)
#' M_Bayes_XCI(pedigree_data=pedigree_data_1,covariate=covariate_data_pedigree_1,trait_type="quantitative",
#'             gamma_prior="uniform")
#' #results:
#' #SNP_Name Point_Estimate HPDI_Lower HPDI_Upper   Rhat
#' #rs123456         0.5972          0     1.5246 1.0016
#'
#' ##example 3:
#' ##pedigree data for quantitative trait with covariates.
#' ##you want to customize the prior of gamma and other unknown parameters.
#' ##users are required to define the prior of gamma and other parameters by "prior_customize".
#' ##The example of "prior_customize" is same as that in example 3 of function "M_Bayes_XCI".
#' set.seed(123456)
#' P_Bayes_XCI(pedigree_data=pedigree_data_1,covariate=covariate_data_pedigree_1,trait_type="quantitative",
#'             gamma_prior="customize",prior_customize=prior_customize)
#' #results:
#' #SNP_Name Point_Estimate HPDI_Lower HPDI_Upper   Rhat
#' #rs123456         0.5728     0.0018     1.4738 1.0006
#'
#' ##example 4:
#' ##pedigree data for qualitative trait with covariates.
#' ##you want to customize the prior of gamma and other unknown parameters.
#' ##users are required to define the prior of gamma and other parameters by "prior_customize".
#' ##The example of "prior_customize" is same as that in example 4 of function "M_Bayes_XCI".
#' set.seed(123456)
#' P_Bayes_XCI(pedigree_data=pedigree_data_3,covariate=covariate_data_pedigree_2,trait_type="qualitative",
#'             gamma_prior="customize",prior_customize=prior_customize)
#' #results:
#' #SNP_Name Point_Estimate HPDI_Lower HPDI_Upper   Rhat
#' #rs234567         1.1429     0.5193     1.9999 1.0001
#'
#' ##example 5:
#' ##pedigree data for quantitative trait with covariates and missing values.
#' ##the prior of gamma is set to truncated normal distribution and other parameters are set to defaults.
#' set.seed(123456)
#' P_Bayes_XCI(pedigree_data=pedigree_data_2,covariate=covariate_data_pedigree_1,trait_type="quantitative",
#'             gamma_prior="normal")
#' #results:
#' #SNP_Name Point_Estimate HPDI_Lower HPDI_Upper   Rhat
#' #rs123456         0.9163     0.1115     1.9141 1.0001
#'
#' ##example 6:
#' ##pedigree data for qualitative trait with covariates and missing values.
#' ##the prior of gamma is set to truncated normal distribution and other parameters are set to defaults.
#' set.seed(123456)
#' P_Bayes_XCI(pedigree_data=pedigree_data_4,covariate=covariate_data_pedigree_2,trait_type="qualitative",
#'             gamma_prior="normal")
#' #results:
#' #SNP_Name Point_Estimate HPDI_Lower HPDI_Upper   Rhat
#' #rs234567         1.1992     0.5012     1.9757 1.0004
#'
#' ##example 7:
#' ##pedigree data for quantitative trait without covariates.
#' ##the prior of gamma is set to truncated normal distribution and other parameters are set to defaults.
#' set.seed(123456)
#' P_Bayes_XCI(pedigree_data=pedigree_data_1,covariate=NULL,trait_type="quantitative",
#'             gamma_prior="normal")
#' #results:
#' #SNP_Name Point_Estimate HPDI_Lower HPDI_Upper   Rhat
#' #rs123456         0.6802     0.0202     1.4178 1.0011
#'
#' ##example 8:
#' ##pedigree data for qualitative trait without covariates.
#' ##the prior of gamma is set to truncated normal distribution and other parameters are set to defaults.
#' set.seed(123456)
#' P_Bayes_XCI(pedigree_data=pedigree_data_3,covariate=NULL,trait_type="qualitative",
#'             gamma_prior="normal")
#' #results:
#' #SNP_Name Point_Estimate HPDI_Lower HPDI_Upper   Rhat
#' #rs234567         1.1201     0.5049     1.9841 1.0021
#'
P_Bayes_XCI<-function (pedigree_data,covariate=NULL,trait_type,trait_missing=NA,genotype_missing=NA,covariate_missing=NA,gamma_prior="normal"
                       ,prior_customize=NULL,chains_num=4,parallel_chains=4,iter_num=2000,warmup_num=1000,acceptance_rate=0.9,decimal=4) {
  # merge data #
  snp_number<-1
  output<-data.frame(SNP_Name=character(),Point_Estimate=numeric(),HPDI_Lower=numeric(),HPDI_Upper=numeric(),Rhat=numeric())
  if (is.null(covariate)){
    covariate_number<-0
    data<-pedigree_data
  } else {
    covariate_number<-ncol(covariate)-5
    data<-merge(pedigree_data,covariate,sort=FALSE)
    if (nrow(data)!=nrow(pedigree_data))
    {stop("The first five columns (famid,iid,fid,mid,sex) of the pedigree_data and covariate datasets are inconsistent")}
  }

  # calculate kinship matrix of females in pedigree data #
  ped<-data
  ped.ID <- pedigree(id=ped[,2], dadid=ped[,3], momid=ped[,4],sex=ped[,5],famid=ped[,1])
  kin <- kinship(ped.ID,"x")
  GRM <- kin[ped$sex==2,ped$sex==2] ; rm(kin)
  data_female<-data[data$sex==2,]

  # Bayesian process #
  if (trait_type=="quantitative"){
    if (covariate_number>0){
      if (gamma_prior=="normal"){
        prior<-"
    data {
      int<lower=0> N ;
      int<lower=0> covariate_number ;
      vector[N] y ;
      vector[N] X0 ;
      vector[N] GRM_values ;
      matrix[N,2] X ;
      matrix[N,covariate_number] covariate ;
    }
    parameters {
      real<lower=0,upper=2> gamma;
      real beta0 ;
      real beta ;
      vector [covariate_number] beta_covariate;
      real<lower=0> tao ;
      real<lower=0> sigma;
    }
    transformed parameters{
      vector[N] mean;
      vector[N] std;
      mean = beta0*X0 + beta*gamma*X[,1] + beta*(2-gamma)*X[,2] + covariate*beta_covariate;
      std = sqrt(tao*GRM_values + sigma^2);
    }
    model {
      y ~ normal(mean,std);
      beta0 ~ normal( 0, 10 );
      beta ~ normal( 0, 10);
      beta_covariate ~ normal(0, 10);
      gamma ~ normal( 1, 1 );
      tao ~ exponential(1);
      sigma ~ exponential(1);
    } "
      } else if (gamma_prior=="uniform"){
        prior<-"
    data {
      int<lower=0> N ;
      int<lower=0> covariate_number ;
      vector[N] y ;
      vector[N] X0 ;
      vector[N] GRM_values ;
      matrix[N,2] X ;
      matrix[N,covariate_number] covariate ;
    }
    parameters {
      real<lower=0,upper=2> gamma;
      real beta0 ;
      real beta ;
      vector [covariate_number] beta_covariate;
      real<lower=0> tao ;
      real<lower=0> sigma;
    }
    transformed parameters{
      vector[N] mean;
      vector[N] std;
      mean = beta0*X0 + beta*gamma*X[,1] + beta*(2-gamma)*X[,2] + covariate*beta_covariate;
      std = sqrt(tao*GRM_values + sigma^2);
    }
    model {
      y ~ normal(mean,std);
      beta0 ~ normal( 0, 10 );
      beta ~ normal( 0, 10);
      beta_covariate ~ normal(0, 10);
      gamma ~ uniform(0, 2);
      tao ~ exponential(1);
      sigma ~ exponential(1);
    } "
      } else if (gamma_prior=="customize" & !is.null(prior_customize))
      {prior<-prior_customize
      } else {stop("Please choose an appropriate gamma_prior or use prior_customize to customize the prior")}

      quantitative_EVD <- cmdstan_model(write_stan_file(prior))
      i<-1
      cov_matrix<-data_female[,(7+snp_number):(6+snp_number+covariate_number)]
      missing_indicator<-!is.na(data_female[,6]) & !is.na(data_female[,6+i]) & !is.na(rowSums(cov_matrix))
      data_tempory<-data_female[missing_indicator,]
      GRM_tempory<-GRM[missing_indicator,missing_indicator]
      cov_tempory<-cov_matrix[missing_indicator,]

      N<-nrow(data_tempory)
      X<-matrix(0,nrow=N,ncol=2)
      X[data_tempory[,6+i]==2|data_tempory[,6+i]==1,1]<-1
      X[data_tempory[,6+i]==2,2]<-1
      y<-data_tempory[,6]

      ei<-eigen(GRM_tempory)
      w<-ei$vectors
      v<-ei$values
      y_EVD<-as.vector(t(w) %*% y)
      X_EVD<-t(w) %*% X
      X0_EVD<-as.vector(t(w) %*% rep(1,N))
      covariate_EVD<-t(w) %*% as.matrix(cov_tempory)

      data_list <- list(y=y_EVD,X0=X0_EVD, X=X_EVD, N=N, GRM_values=v, covariate_number=covariate_number, covariate=covariate_EVD)
      fit <-quantitative_EVD$sample( data=data_list, chains=chains_num, parallel_chains=parallel_chains, iter_sampling=iter_num, iter_warmup=warmup_num, adapt_delta=acceptance_rate, show_messages=FALSE, refresh=0.1*(iter_num+warmup_num))
      draws <- fit$draws("gamma")
      Rhat<-round(fit$summary()$ rhat[2],decimal)
      Mode_gamma <- round(HMC_mode(draws),decimal)
      HPDI_gamma <- round(HMC_HPDI(draws),decimal)
      output[i,]<-c(colnames(data)[6+i],Mode_gamma,HPDI_gamma,Rhat)
    }
    if (covariate_number==0){
      if (gamma_prior=="normal"){
        prior<-"
    data {
      int<lower=0> N ;
      vector[N] y ;
      vector[N] X0 ;
      vector[N] GRM_values ;
      matrix[N,2] X ;
    }
    parameters {
      real<lower=0,upper=2> gamma;
      real beta0 ;
      real beta ;
      real<lower=0> tao ;
      real<lower=0> sigma;
    }
    transformed parameters{
      vector[N] mean;
      vector[N] std;
      mean = beta0*X0 + beta*gamma*X[,1] + beta*(2-gamma)*X[,2];
      std = sqrt(tao*GRM_values + sigma^2);
    }
    model {
      y ~ normal(mean,std);
      beta0 ~ normal( 0, 10 );
      beta ~ normal( 0, 10);
      gamma ~ normal( 1, 1 );
      tao ~ exponential(1);
      sigma ~ exponential(1);
    } "
      } else if (gamma_prior=="uniform"){
        prior<-"
    data {
      int<lower=0> N ;
      vector[N] y ;
      vector[N] X0 ;
      vector[N] GRM_values ;
      matrix[N,2] X ;
    }
    parameters {
      real<lower=0,upper=2> gamma;
      real beta0 ;
      real beta ;
      real<lower=0> tao ;
      real<lower=0> sigma;
    }
    transformed parameters{
      vector[N] mean;
      vector[N] std;
      mean = beta0*X0 + beta*gamma*X[,1] + beta*(2-gamma)*X[,2];
      std = sqrt(tao*GRM_values + sigma^2);
    }
    model {
      y ~ normal(mean,std);
      beta0 ~ normal( 0, 10 );
      beta ~ normal( 0, 10);
      gamma ~ uniform(0, 2);
      tao ~ exponential(1);
      sigma ~ exponential(1);
    } "
      } else if (gamma_prior=="customize" & !is.null(prior_customize))
      {prior<-prior_customize
      } else {stop("Please choose an appropriate gamma_prior or use prior_customize to customize the prior")}

      quantitative_EVD <- cmdstan_model(write_stan_file(prior))
      i<-1
      missing_indicator<-!is.na(data_female[,6]) & !is.na(data_female[,6+i])
      data_tempory<-data_female[missing_indicator,]
      GRM_tempory<-GRM[missing_indicator,missing_indicator]
      N<-nrow(data_tempory)

      X<-matrix(0,nrow=N,ncol=2)
      X[data_tempory[,6+i]==2|data_tempory[,6+i]==1,1]<-1
      X[data_tempory[,6+i]==2,2]<-1
      y<-data_tempory[,6]

      ei<-eigen(GRM_tempory)
      w<-ei$vectors
      v<-ei$values
      y_EVD<-as.vector(t(w) %*% y)
      X_EVD<-t(w) %*% X
      X0_EVD<-as.vector(t(w) %*% rep(1,N))

      data_list <- list(y=y_EVD,X0=X0_EVD, X=X_EVD, N=N, GRM_values=v)
      fit <-quantitative_EVD$sample( data=data_list, chains=chains_num, parallel_chains=parallel_chains, iter_sampling=iter_num, iter_warmup=warmup_num, adapt_delta=acceptance_rate, show_messages=FALSE, refresh=0.1*(iter_num+warmup_num))
      draws <- fit$draws("gamma")
      Rhat<-round(fit$summary()$ rhat[2],decimal)
      Mode_gamma <- round(HMC_mode(draws),decimal)
      HPDI_gamma <- round(HMC_HPDI(draws),decimal)
      output[i,]<-c(colnames(data)[6+i],Mode_gamma,HPDI_gamma,Rhat)
    }
  }

  if (trait_type=="qualitative"){
    if (covariate_number>0){
      if (gamma_prior=="normal"){
        prior<-"
    data {
      int<lower=0> N ;
      array[N] int y ;
      int<lower=0> covariate_number ;
      matrix[N,2] X;
      matrix[N,N] GRM_female;
      matrix[N,covariate_number] covariate ;
    }

    transformed data {
      matrix[N,N] C;
      C = cholesky_decompose(GRM_female);
    }

    parameters {
      real<lower=0,upper=2> gamma;
      real beta0 ;
      real beta ;
      real<lower=0> tao ;
      vector [covariate_number] beta_covariate;
      vector[N] z;
    }

    model {
      vector[N] p;
      vector[N] d;
      z ~ normal (0,1);
      d = tao *( C * z );
      p = beta0 + beta*gamma*X[,1] + beta*(2-gamma)*X[,2] + covariate*beta_covariate + d;
      y ~ bernoulli_logit(p);
      beta0 ~ normal(0, 10);
      beta ~ normal(0, 10);
      beta_covariate ~ normal(0, 10);
      gamma ~ normal(1, 1);
      tao ~ exponential(1);
    }
    "
      } else if (gamma_prior=="uniform"){
        prior<-"
    data {
      int<lower=0> N ;
      array[N] int y ;
      int<lower=0> covariate_number ;
      matrix[N,2] X;
      matrix[N,N] GRM_female;
      matrix[N,covariate_number] covariate ;
    }

    transformed data {
      matrix[N,N] C;
      C = cholesky_decompose(GRM_female);
    }

    parameters {
      real<lower=0,upper=2> gamma;
      real beta0 ;
      real beta ;
      real<lower=0> tao ;
      vector [covariate_number] beta_covariate;
      vector[N] z;
    }

    model {
      vector[N] p;
      vector[N] d;
      z ~ normal (0,1);
      d = tao *( C * z );
      p = beta0 + beta*gamma*X[,1] + beta*(2-gamma)*X[,2] + covariate*beta_covariate + d;
      y ~ bernoulli_logit(p);
      beta0 ~ normal( 0, 10 );
      beta ~ normal( 0, 10);
      beta_covariate ~ normal(0, 10);
      gamma ~ uniform( 0, 2 );
      tao ~ exponential(1);
    }
    "
      } else if (gamma_prior=="customize" & !is.null(prior_customize))

      {prior<-prior_customize

      } else {stop("Please choose an appropriate gamma_prior or use prior_customize to customize the prior")}

      qualitative_cholesky <- cmdstan_model(write_stan_file(prior))

      i<-1
      cov_matrix<-data_female[,(7+snp_number):(6+snp_number+covariate_number)]
      missing_indicator<-!is.na(data_female[,6]) & !is.na(data_female[,6+i]) & !is.na(rowSums(cov_matrix))
      data_tempory<-data_female[missing_indicator,]
      GRM_tempory<-as.matrix(GRM[missing_indicator,missing_indicator])
      cov_tempory<-cov_matrix[missing_indicator,]
      N<-nrow(data_tempory)

      X<-matrix(0,nrow=N,ncol=2)
      X[data_tempory[,6+i]==2|data_tempory[,6+i]==1,1]<-1
      X[data_tempory[,6+i]==2,2]<-1
      y<-data_tempory[,6]

      data_list <- list(y=y,X=X, N=N, GRM_female=GRM_tempory, covariate_number=covariate_number, covariate=cov_tempory)
      fit <-qualitative_cholesky$sample( data=data_list, chains=chains_num, parallel_chains=parallel_chains, iter_sampling=iter_num, iter_warmup=warmup_num, adapt_delta=acceptance_rate, show_messages=FALSE, refresh=0.1*(iter_num+warmup_num))
      draws <- fit$draws("gamma")
      Rhat<-round(fit$summary()$ rhat[2],decimal)
      Mode_gamma <- round(HMC_mode(draws),decimal)
      HPDI_gamma <- round(HMC_HPDI(draws),decimal)

      output[i,]<-c(colnames(data)[6+i],Mode_gamma,HPDI_gamma,Rhat)
    }
    if (covariate_number==0){
      if (gamma_prior=="normal"){
        prior<-"
    data {
      int<lower=0> N ;
      array[N] int y ;
      matrix[N,2] X;
      matrix[N,N] GRM_female;
    }

    transformed data {
      matrix[N,N] C;
      C = cholesky_decompose(GRM_female);
    }

    parameters {
      real<lower=0,upper=2> gamma;
      real beta0 ;
      real beta ;
      real<lower=0> tao ;
      vector[N] z;
    }

    model {
      vector[N] p;
      vector[N] d;
      z ~ normal (0,1);
      d = tao *( C * z );
      p = beta0 + beta*gamma*X[,1] + beta*(2-gamma)*X[,2] + d;
      y ~ bernoulli_logit(p);
      beta0 ~ normal( 0, 10 );
      beta ~ normal( 0, 10);
      gamma ~ normal( 1, 1 );
      tao ~ exponential(1);
    }
    "
      } else if (gamma_prior=="uniform"){
        prior<-"
    data {
      int<lower=0> N ;
      array[N] int y ;
      matrix[N,2] X;
      matrix[N,N] GRM_female;
    }

    transformed data {
      matrix[N,N] C;
      C = cholesky_decompose(GRM_female);
    }

    parameters {
      real<lower=0,upper=2> gamma;
      real beta0 ;
      real beta ;
      real<lower=0> tao ;
      vector[N] z;
    }

    model {
      vector[N] p;
      vector[N] d;
      z ~ normal (0,1);
      d = tao *( C * z );
      p = beta0 + beta*gamma*X[,1] + beta*(2-gamma)*X[,2] + d;
      y ~ bernoulli_logit(p);
      beta0 ~ normal( 0, 10 );
      beta ~ normal( 0, 10);
      gamma ~ uniform( 0, 2 );
      tao ~ exponential(1);
    }
    "
      } else if (gamma_prior=="customize" & !is.null(prior_customize))

      {prior<-prior_customize

      } else {stop("Please choose an appropriate gamma_prior or use prior_customize to customize the prior")}

      qualitative_cholesky <- cmdstan_model(write_stan_file(prior))

      i<-1
      missing_indicator<-!is.na(data_female[,6]) & !is.na(data_female[,6+i])
      data_tempory<-data_female[missing_indicator,]
      GRM_tempory<-as.matrix(GRM[missing_indicator,missing_indicator])
      N<-nrow(data_tempory)

      X<-matrix(0,nrow=N,ncol=2)
      X[data_tempory[,6+i]==2|data_tempory[,6+i]==1,1]<-1
      X[data_tempory[,6+i]==2,2]<-1
      y<-data_tempory[,6]

      data_list <- list(y=y,X=X, N=N, GRM_female=GRM_tempory)
      fit <-qualitative_cholesky$sample( data=data_list, chains=chains_num, parallel_chains=parallel_chains, iter_sampling=iter_num, iter_warmup=warmup_num, adapt_delta=acceptance_rate, show_messages=FALSE, refresh=0.1*(iter_num+warmup_num))
      draws <- fit$draws("gamma")
      Rhat<-round(fit$summary()$ rhat[2],decimal)
      Mode_gamma <- round(HMC_mode(draws),decimal)
      HPDI_gamma <- round(HMC_HPDI(draws),decimal)

      output[i,]<-c(colnames(data)[6+i],Mode_gamma,HPDI_gamma,Rhat)
    }
  }
  return(output)
}



