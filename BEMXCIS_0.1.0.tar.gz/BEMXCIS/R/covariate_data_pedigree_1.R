#' @title A dataset containing the covariates for quantitative traits based on only general pedigrees
#'
#' @description The dataset contains two covariates for 30 pedigrees with 260 individuals (130 females and 130 males).
#'
#' @docType data
#' @keywords datasets
#' @name covariate_data_pedigree_1
#' @usage covariate_data_pedigree_1
#' @format
#' \describe{
#' \item{famid}{Pedigree ID.}
#' \item{iid}{Individual ID.}
#' \item{fid}{Father ID.}
#' \item{mid}{Mother ID.}
#' \item{sex}{The genetic sex of the individual, coded as 1 for males and 2 for females, following the PLINK default coding.}
#' \item{covariate1}{A quantitative covariate.}
#' \item{covariate2}{A qualitative covariate.}
#' }
NULL
